document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('loginForm');
    const passwordInput = document.getElementById('password');
    const passwordError = document.getElementById('passwordError');

    if (!form) return;

    form.addEventListener('submit', function(e) {
        // Mencegah form kirim data secara default
        e.preventDefault();

        const nama = document.getElementById('nama').value.trim();
        const password = passwordInput.value;

        // PAGAR UTAMA: Jika kurang dari 8, LANGSUNG STOP.
        if (password.length < 8) {
            alert('AKSES DITOLAK: Password harus minimal 8 karakter!');
            passwordError.textContent = 'Password minimal 8 karakter!';
            passwordInput.focus();
            return; // Ini yang memastikan kode di bawahnya tidak jalan
        }

        // Ambil data dari localStorage
        let users = JSON.parse(localStorage.getItem('users')) || [];

        // Cari user yang COCOK
        const user = users.find(u => u.nama.toLowerCase() === nama.toLowerCase() && u.password === password);

        if (user) {
            // Jika ketemu, pastikan data yang ditemukan juga passwordnya >= 8 (Double Check)
            if (user.password.length < 8) {
                alert('Akun lama terdeteksi dengan password tidak aman. Silakan register ulang!');
                return;
            }

            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('currentUser', JSON.stringify(user)); 
            alert(`Login berhasil, ${user.nama}!`);
            window.location.href = 'home'; 
        } else {
            alert('Nama atau password salah!');
        }
    });
});