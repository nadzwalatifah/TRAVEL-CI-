document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const passwordError = document.getElementById('passwordError');
    const registerForm = document.getElementById('registerForm');
    const confirmPasswordInput = document.getElementById('password_confirmation');

    // Validasi password harus tepat 8 karakter
    passwordInput.addEventListener('input', function() {
        const passwordLength = this.value.length;
        
        // Blokir input jika sudah 8 karakter
        if (passwordLength > 8) {
            this.value = this.value.slice(0, 8);
            passwordError.textContent = 'Password maksimal 8 karakter';
            return;
        }
        
        if (passwordLength > 0 && passwordLength < 8) {
            passwordError.textContent = 'Password harus tepat 8 karakter (sisa: ' + (8 - passwordLength) + ')';
            this.setCustomValidity('Password harus tepat 8 karakter');
        } else if (passwordLength === 8) {
            passwordError.textContent = '';
            passwordError.style.color = 'green';
            passwordError.textContent = '✓ Password valid (8 karakter)';
            this.setCustomValidity('');
        } else {
            passwordError.textContent = '';
            this.setCustomValidity('');
        }
    });

    // Validasi saat form di-submit
    registerForm.addEventListener('submit', function(e) {
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        // Cek password harus tepat 8 karakter
        if (password.length !== 8) {
            e.preventDefault();
            passwordError.style.color = 'red';
            passwordError.textContent = 'Password harus tepat 8 karakter!';
            passwordInput.focus();
            return false;
        }

        // Cek kecocokan password
        if (password !== confirmPassword) {
            e.preventDefault();
            alert('Password dan Konfirmasi Password tidak sama!');
            confirmPasswordInput.focus();
            return false;
        }
    });

    // Validasi confirm password
    confirmPasswordInput.addEventListener('input', function() {
        // Blokir input jika sudah 8 karakter
        if (this.value.length > 8) {
            this.value = this.value.slice(0, 8);
        }
        
        if (passwordInput.value !== this.value && this.value.length > 0) {
            this.setCustomValidity('Password tidak sama');
        } else {
            this.setCustomValidity('');
        }
    });
});