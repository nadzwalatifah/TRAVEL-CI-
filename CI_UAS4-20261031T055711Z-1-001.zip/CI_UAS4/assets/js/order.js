// Pastikan DOM sudah siap sebelum menjalankan script
document.addEventListener('DOMContentLoaded', function() {
  const destSelect = document.getElementById('destinationSelect');
  const qtyInput = document.getElementById('quantityInput');
  const totalDisplay = document.getElementById('totalPriceDisplay');
  const idDestVal = document.getElementById('id_destinasi_val');
  const totalInput = document.getElementById('totalInput');

  function calculate() {
    const selected = destSelect.options[destSelect.selectedIndex];
    const priceStr = selected.getAttribute('data-price');
    const price = parseInt(priceStr) || 0;
    const id = selected.getAttribute('data-id') || "";
    const qty = parseInt(qtyInput.value) || 1;
    
    // Set id_destinasi
    idDestVal.value = id;

    // Set max qty sesuai stok (jika tersedia)
    const stock = parseInt(selected.getAttribute('data-stock')) || null;
    if (stock !== null && !isNaN(stock)) {
      qtyInput.max = stock;
      // jika qty melebihi stok, kurangi ke stok
      if (qty > stock) {
        qtyInput.value = stock;
      }
    } else {
      qtyInput.max = 50; // default
    }
    
    // Hitung total
    const total = price * parseInt(qtyInput.value);
    
    // Update tampilan total
    totalDisplay.textContent = 'Total: Rp. ' + total.toLocaleString('id-ID');
    
    // PENTING: Simpan total ke hidden input
    if (totalInput) {
      totalInput.value = total;
    }
    
    // Debug: Cek nilai yang akan dikirim
    console.log('=== DEBUG INFO ===');
    console.log('Destinasi ID:', id);
    console.log('Harga per tiket:', price);
    console.log('Jumlah tiket:', qty);
    console.log('Total yang akan dikirim:', total);
    console.log('Hidden input value:', totalInput ? totalInput.value : 'NOT FOUND');
  }

  // Event listeners
  if (destSelect) {
    destSelect.addEventListener('change', calculate);
  }
  
  if (qtyInput) {
    qtyInput.addEventListener('input', calculate);
  }

  // Hitung saat halaman dimuat
  calculate();

  // Form submission dengan validasi
  const orderForm = document.getElementById('orderForm');
  if (orderForm) {
    orderForm.onsubmit = function(e) {
      // Pastikan total sudah dihitung
      calculate();
      
      const totalValue = totalInput ? totalInput.value : '0';
      
      // Debug sebelum submit
      console.log('=== BEFORE SUBMIT ===');
      console.log('Total value yang akan dikirim:', totalValue);
      
      // Validasi total tidak boleh 0
      if (parseInt(totalValue) === 0) {
        alert('Silakan pilih destinasi terlebih dahulu!');
        e.preventDefault();
        return false;
      }
      
      // Konfirmasi
      const confirmed = confirm("Apakah Anda yakin ingin melakukan pemesanan ini?\n\nTotal: Rp. " + parseInt(totalValue).toLocaleString('id-ID'));
      
      if (!confirmed) {
        e.preventDefault();
        return false;
      }
      
      return true;
    };
  }
});