// assets/js/script.js
document.addEventListener('DOMContentLoaded', function() {
    console.log("Footer loaded successfully.");
});