// js/loadnavbar.js (versi dimodifikasi)
function loadNavbar() {
    const placeholder = document.getElementById('navbar-placeholder');
    if (!placeholder) {
        console.error('Placeholder #navbar-placeholder tidak ditemukan! Pastikan ID ada di HTML.');
        return;
    }

    placeholder.innerHTML = '<div style="text-align: center; padding: 1rem; color: #666;">Loading navbar...</div>'; // Loading message

    fetch('navbar.html')  // Ubah path jika perlu, misalnya 'includes/navbar.html'
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status} ${response.statusText}. Pastikan navbar.html ada di root folder.`);
            }
            console.log('Fetch navbar.html berhasil (status:', response.status + ').');
            return response.text();
        })
        .then(html => {
            console.log('HTML navbar diterima, memproses...');
            placeholder.innerHTML = html;

            // Re-execute scripts di navbar.html
            const scripts = placeholder.querySelectorAll('script');
            console.log('Ditemukan', scripts.length, 'script di navbar untuk di-re-execute.');
            scripts.forEach(oldScript => {
                const newScript = document.createElement('script');
                Array.from(oldScript.attributes).forEach(attr => {
                    newScript.setAttribute(attr.name, attr.value);
                });
                if (oldScript.src === '') {
                    newScript.textContent = oldScript.textContent;
                } else {
                    newScript.async = true;
                }
                oldScript.parentNode.replaceChild(newScript, oldScript);
            });
            console.log('Semua scripts di navbar di-re-execute.');

            // Update nav links dengan delay lebih lama jika perlu
            if (typeof updateNavLinks === 'function') {
                setTimeout(updateNavLinks, 200);  // Diubah dari 100 ke 200ms untuk stabilitas
                console.log('updateNavLinks dipanggil setelah load.');
            } else {
                console.error('updateNavLinks function not found! Pastikan js/nav.js di-load sebelumnya.');
            }

            console.log('Navbar berhasil dimuat sepenuhnya!');
        })
        .catch(error => {
            console.error('Error loading navbar:', error);
            // Fallback navbar (ditambahkan pengecekan role sederhana)
            const isAdmin = localStorage.getItem('userRole') === 'admin';
            const fallbackLinks = isAdmin ?
                `<li><a href="admin.html" style="color: #333; text-decoration: none; padding: 0.3rem 0.6rem;">CRUD</a></li><li><a href="admin-purchase.html" style="color: #333; text-decoration: none; padding: 0.3rem 0.6rem;">Manage Purchases</a></li>` :
                `<li><a href="login.html" style="color: #333; text-decoration: none; padding: 0.3rem 0.6rem;">Login</a></li><li><a href="register.html" style="color: #333; text-decoration: none; padding: 0.3rem 0.6rem;">Register</a></li>`;
            placeholder.innerHTML = `
                <nav style="background: #f8f9fa; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="font-weight: bold; font-size: 1.5rem; color: #007bff;">
                        <a href="index.html" style="text-decoration: none; color: inherit;">EXPLORE BEYOND</a>
                    </div>
                    <ul style="list-style: none; display: flex; gap: 1rem; margin: 0; padding: 0;">
                        ${fallbackLinks}
                        <li><a href="kontak.html" style="color: #333; text-decoration: none; padding: 0.3rem 0.6rem;">Contact Us</a></li>
                    </ul>
                </nav>
            `;
            console.log('Fallback navbar ditampilkan dengan role check.');
            if (typeof updateNavLinks === 'function') {
                updateNavLinks();
            }
        });
}

// Auto-load saat DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadNavbar);
} else {
    loadNavbar();
}