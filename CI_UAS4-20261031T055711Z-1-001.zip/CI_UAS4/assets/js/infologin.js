// js/infologin.js (sederhana: cegah klik card jika belum login)
function isLoggedIn() {
    return localStorage.getItem('isLoggedIn') === 'true';
}

document.addEventListener('DOMContentLoaded', function() {
    const cardLinks = document.querySelectorAll('.row a.col');
    cardLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            if (!isLoggedIn()) {
                event.preventDefault();
                alert('Anda harus login terlebih dahulu!');
                window.location.href = 'login.php'; // Redirect ke login
            }
            // Jika login, link normal
        });
    });
});
