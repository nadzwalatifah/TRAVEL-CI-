
           // JS gabungan untuk toggle berdasarkan login dan role
           function isLoggedIn() {
               return localStorage.getItem('isLoggedIn') === 'true';
           }

           function isAdmin() {
               return localStorage.getItem('userRole') === 'admin';
           }

           function updateNavLinks() {
               const userLinks = document.querySelectorAll('.user-links');
               const adminLinks = document.querySelectorAll('.admin-links');
               const loginLink = document.getElementById('loginLink');
               const registerLink = document.getElementById('registerLink');
               const historyLink = document.getElementById('historyLink');
               const orderLink = document.getElementById('orderLink');
               const logoutLink = document.getElementById('logoutLink');

               if (isLoggedIn() && isAdmin()) {
                   // Tampilkan link admin, sembunyikan user
                   userLinks.forEach(link => link.style.display = 'none');
                   adminLinks.forEach(link => link.style.display = 'block');
                   console.log('Admin navbar active.');
               } else if (isLoggedIn()) {
                   // Tampilkan link user (history/order/logout), sembunyikan admin
                   userLinks.forEach(link => link.style.display = 'block');
                   adminLinks.forEach(link => link.style.display = 'none');
                   if (loginLink) loginLink.parentElement.style.display = 'none';
                   if (registerLink) registerLink.parentElement.style.display = 'none';
                   if (historyLink) historyLink.style.display = 'block';
                   if (orderLink) orderLink.style.display = 'block';
                   if (logoutLink) logoutLink.style.display = 'block';
                   console.log('User navbar active.');
               } else {
                   // Tampilkan link user default (login/register), sembunyikan admin dan logged-in links
                   userLinks.forEach(link => link.style.display = 'block');
                   adminLinks.forEach(link => link.style.display = 'none');
                   if (historyLink) historyLink.style.display = 'none';
                   if (orderLink) orderLink.style.display = 'none';
                   if (logoutLink) logoutLink.style.display = 'none';
                   console.log('Guest navbar active.');
               }
           }

           // Auto jalankan saat halaman load
           document.addEventListener('DOMContentLoaded', updateNavLinks);
