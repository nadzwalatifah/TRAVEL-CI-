# Implementasi Role-Based Login & Admin Redirection

## Deskripsi
Sistem login sekarang mendukung dua role: **user** dan **admin**. Ketika login sebagai admin, user akan langsung diarahkan ke halaman admin dashboard.

## Perubahan yang Dilakukan

### 1. **User Model** (`application/models/user_model.php`)
- Ditambahkan method `get_role()` untuk mengambil role user dari database

### 2. **Auth Controller** (`application/controllers/auth.php`)
- Update method `login()` untuk:
  - Menyimpan `user_id` dan `role` di session
  - Redirect berdasarkan role:
    - Jika role = 'admin' → redirect ke `admin/index`
    - Jika role = 'user' → redirect ke `home`

### 3. **Admin Controller** (`application/controllers/Admin.php`) - BARU
- Controller untuk mengelola halaman admin
- Method `check_admin_access()` untuk melindungi halaman admin (hanya admin yang bisa akses)
- Method `index()` - Dashboard admin
- Method `users()` - Kelola pengguna
- Method `logout()` - Logout dan kembali ke halaman login

### 4. **Admin Views** - BARU
- `application/views/admin/index.php` - Admin dashboard
- `application/views/admin/users.php` - Halaman manage users

## Persiapan Database

Pastikan tabel `users` memiliki kolom `role`. Jika belum ada, jalankan query berikut:

```sql
ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user';

-- Update data yang sudah ada (jika diperlukan)
UPDATE users SET role = 'user' WHERE role IS NULL;
```

### Contoh Insert User dengan Role

```sql
-- User biasa
INSERT INTO users (nama, email, password, role) 
VALUES ('John User', 'john@example.com', 'password123', 'user');

-- Admin
INSERT INTO users (nama, email, password, role) 
VALUES ('Admin Master', 'admin@example.com', 'adminpass', 'admin');
```

## Cara Kerja

1. **Login sebagai User**:
   - Username: john (role: user)
   - Akan diarahkan ke `home` page

2. **Login sebagai Admin**:
   - Username: admin (role: admin)
   - Akan diarahkan ke `admin` page (Dashboard Admin)

3. **Proteksi Halaman Admin**:
   - Hanya user dengan role = 'admin' yang bisa akses halaman admin
   - User biasa yang mencoba akses admin akan diarahkan ke halaman login

## Struktur Role

- **user**: User biasa, akses ke halaman public/home
- **admin**: Administrator, akses ke admin dashboard dan manage users

## Testing

1. Buat dua user di database, satu dengan role 'user' dan satu dengan role 'admin'
2. Login dengan user biasa → akan masuk ke home page
3. Logout, kemudian login dengan admin → akan masuk ke admin dashboard
4. Coba akses `/admin` tanpa login → akan diarahkan ke halaman login
5. Coba akses `/admin` dengan user biasa → akan diarahkan ke halaman login

## File yang Dimodifikasi/Dibuat

- ✏️ `application/models/user_model.php` (Modified)
- ✏️ `application/controllers/auth.php` (Modified)
- ✨ `application/controllers/Admin.php` (Created)
- ✨ `application/views/admin/index.php` (Created)
- ✨ `application/views/admin/users.php` (Created)
