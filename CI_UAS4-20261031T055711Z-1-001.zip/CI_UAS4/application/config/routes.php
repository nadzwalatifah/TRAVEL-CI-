<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home/index';

$route['login']    = 'auth/login';
$route['register'] = 'auth/register';
$route['home']     = 'home/index';
$route['history']  = 'History/index';
$route['lombok']   = 'home/order';
$route['bali']     = 'home/order';
$route['papua']    = 'home/order';
$route['contactus']    = 'auth/contactus';
$route['auth/register'] = 'auth/register';
$route['auth/store_register'] = 'auth/store_register';
$route['auth/login'] = 'auth/login';
$route['auth'] = 'auth/index';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

