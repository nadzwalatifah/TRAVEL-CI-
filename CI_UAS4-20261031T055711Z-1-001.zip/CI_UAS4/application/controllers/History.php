<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class History extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('order_model');
        $this->load->helper('url');
    }

    public function index() {
        $data['orders'] = $this->order_model->get_all_orders();
        $this->load->view('history_view', $data);
    }

    // Method bayar dihapus dari sini

    public function hapus($id) {
        if ($this->order_model->delete_order($id)) {
            $this->session->set_flashdata('msg', 'Pesanan berhasil dihapus');
        }
        redirect('history');
    }
public function download_tiket($id) {
    // Memberikan notifikasi sukses tanpa proses unduh file
    $this->session->set_flashdata('msg', 'Tiket #ORD-' . $id . ' berhasil di download ke perangkat Anda.');
    redirect('history');

}
}