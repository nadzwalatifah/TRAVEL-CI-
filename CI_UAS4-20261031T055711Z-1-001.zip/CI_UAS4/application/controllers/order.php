<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class order extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('order_model');
        $this->load->helper('url');
    }

    public function index() {
        // Ambil data destinasi dari database dan kirim ke view
        $this->load->model('Destinasi_model');
        $data['destinasi'] = $this->Destinasi_model->get_all_destinasi();
        // Karena di VS Code Anda file ada di folder auth, maka tambahkan 'auth/'
        $this->load->view('auth/order', $data); 
    }

    public function simpan() {
        $id_dest = $this->input->post('id_destinasi');
        $qty = (int) $this->input->post('jumlah_tiket');

        // validasi dasar
        if (empty($id_dest) || $qty <= 0) {
            echo "<script>alert('Data destinasi atau jumlah tiket tidak valid.'); window.location='" . site_url('order') . "';</script>";
            return;
        }

        // Ambil model destinasi untuk mengurangi stock
        $this->load->model('Destinasi_model');

        // Mulai transaksi agar update stock + insert order atomik
        $this->db->trans_begin();

        // Coba decrement stock secara atomik
        $decremented = $this->Destinasi_model->decrement_stock($id_dest, $qty);

        if (! $decremented) {
            $this->db->trans_rollback();
            echo "<script>alert('Maaf, stok tiket tidak mencukupi.'); window.location='" . site_url('order') . "';</script>";
            return;
        }

        // Siapkan data order seperti sebelumnya
        $data = array(
            'id_destinasi'      => $id_dest,
            'nama_lengkap'      => $this->input->post('nama_lengkap'),
            'email'             => $this->input->post('email'),
            'no_hp'             => $this->input->post('no_hp'),
            'jenis_kelamin'     => $this->input->post('jenis_kelamin'),
            'tbt'               => $this->input->post('tbt'),
            'destinasi'         => $this->input->post('destinasi'),
            'tanggal_penerbangan' => $this->input->post('tanggal_penerbangan'),
            'jumlah_tiket'      => $qty,
            'metode_pembayaran' => $this->input->post('metode_pembayaran'),
            // NOTE: file upload handling for bukti belum diubah — keep original behavior for now
            'bukti'             => $this->input->post('bukti'),
            'total'             => $this->input->post('total'),
            'date'              => date('Y-m-d H:i:s')
        );

        $inserted = $this->order_model->simpan_data($data);

        if ($inserted && $this->db->trans_status()) {
            $this->db->trans_commit();
            echo "<script>alert('Berhasil! Pesanan Anda diterima.'); window.location='" . site_url('home') . "';</script>";
            return;
        } else {
            // jika insert gagal, rollback dan kembalikan stock
            $this->db->trans_rollback();
            echo "<script>alert('Gagal memproses pesanan. Silakan coba lagi.'); window.location='" . site_url('order') . "';</script>";
            return;
        }
    }
}

