<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_pelanggan extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->check_admin_access();
        $this->load->model('Pesanan_model');
    }

    private function check_admin_access() {
        if (!$this->session->userdata('login') || $this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
    }

    /**
     * HALAMAN DATA PELANGGAN / PESANAN
     */
    public function index() {
    $data['title'] = 'Data Pelanggan';

    $cari = $this->input->get('cari', true);

    if ($cari) {
        $data['pesanan'] = $this->Pesanan_model->search_pesanan($cari);
    } else {
        $data['pesanan'] = $this->Pesanan_model->get_all_pesanan();
    }

    // 🔥 INI YANG MEMANGGIL VIEW
    $this->load->view('admin/data_pelanggan', $data);
}

    /**
     * HAPUS PESANAN
     */
    public function delete($id) {
        $pesanan = $this->Pesanan_model->get_by_id($id);

        if (!$pesanan) {
            $this->session->set_flashdata('error', 'Data pesanan tidak ditemukan!');
            redirect('admin_pelanggan');
        }

        // Hapus bukti pembayaran
        if (!empty($pesanan->bukti)) {
            $path = FCPATH . 'uploads/' . $pesanan->bukti;
            if (file_exists($path)) {
                unlink($path);
            }
        }

        if ($this->Pesanan_model->delete($id)) {
            $this->session->set_flashdata('success', 'Data pesanan berhasil dihapus!');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus data!');
        }

        redirect('admin_pelanggan');
    }

    /**
     * EDIT PESANAN (OPSIONAL)
     */
    public function edit($id) {
        $data['pesanan'] = $this->Pesanan_model->get_by_id($id);

        if (!$data['pesanan']) {
            $this->session->set_flashdata('error', 'Data pesanan tidak ditemukan!');
            redirect('admin_pelanggan');
        }

        $this->load->view('admin/pesanan_edit', $data);
    }
}