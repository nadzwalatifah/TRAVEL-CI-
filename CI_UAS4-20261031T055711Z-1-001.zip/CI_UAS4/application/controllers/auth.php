<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function index() {
        if ($this->session->userdata('login') == true) {
            redirect('home');
        }
        $this->load->view('login');
    }

    // Tambahkan method ini
    public function register() {
        if ($this->session->userdata('login') == true) {
            redirect('home');
        }
        $this->load->view('register');
    }

    public function login() {
        if ($this->input->post()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            if (strlen($password) != 8) {
                $this->session->set_flashdata('login_error', 'Password harus tepat 8 karakter!');
                redirect('auth/login');
            }

            $this->load->model('User_model');
            $user = $this->User_model->login($username, $password);

            if ($user) {
                $this->session->set_userdata([
                    'login'    => true,
                    'username' => $user->username,
                    'user_id'  => $user->id,
                    'role'     => isset($user->role) ? $user->role : 'user'
                ]);
                if ($user->role === 'admin') {
                    redirect('admin');
                } else {
                    redirect('home');
                }
            } else {
                $this->session->set_flashdata('login_error', 'Username atau Password salah!');
                redirect('auth/login');
            }
        }
        $this->load->view('login');
    }

    public function store_register() {
        $this->load->model('User_model');
        
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $password_confirmation = $this->input->post('password_confirmation');

        // Validasi password harus tepat 8 karakter
        if (strlen($password) != 8) {
            $this->session->set_flashdata('register_error', 'Password harus tepat 8 karakter!');
            redirect('auth/register');
            return;
        }

        // Validasi password confirmation
        if ($password !== $password_confirmation) {
            $this->session->set_flashdata('register_error', 'Password dan Konfirmasi Password tidak sama!');
            redirect('auth/register');
            return;
        }

        $data = array(
            'nama' => $nama,
            'email' => $email,
            'password' => $password
        );

        if ($this->User_model->register($data)) {
            $this->session->set_flashdata('register_success', 'Register Berhasil! Silakan Login.');
            redirect('auth/index');
        } else {
            $this->session->set_flashdata('register_error', 'Register Gagal! Email mungkin sudah terdaftar.');
            redirect('auth/register');
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('home');
    }

    public function home() {
        $this->load->view('auth/home');
    }
    
    public function order() {
        redirect('home/order');
    }

    public function data() {
        $this->load->view('admin/data');
    }
    
    public function contactus() {
        $this->load->view('contactus');
    }
}