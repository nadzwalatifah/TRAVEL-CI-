<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->check_admin_access();
    }

    private function check_admin_access() {
        // Cek apakah user sudah login dan memiliki role admin
        if (!$this->session->userdata('login') || $this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
    }

    public function index() {
        $data['title'] = 'Admin Dashboard';
        $this->load->model('Destinasi_model');
        // Ambil data destinasi dari database
        $cari = $this->input->get('cari');
        if ($cari) {
            $data['destinasi'] = $this->Destinasi_model->search_destinasi($cari);
        } else {
            $data['destinasi'] = $this->Destinasi_model->get_all_destinasi();
        }
        
        $this->load->view('admin/index', $data);
    }

    public function users() {
        $data['title'] = 'Manage Users';
        $this->load->model('User_model');
        $data['users'] = $this->db->get('users')->result();
        $this->load->view('admin/users', $data);
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('home');
    }

    public function destinasi_tambah() {
        $data['title'] = 'Tambah Destinasi';
        $this->load->view('admin/destinasi_tambah', $data);
    }

    public function store_destinasi() {
        $this->load->model('Destinasi_model');
        
        $data = array(
            'nama_destinasi' => $this->input->post('nama_destinasi'),
            'stock' => $this->input->post('stock'),
            'harga' => $this->input->post('harga'),
            
        );

        // Handle file upload
        if (!empty($_FILES['gambar']['name'])) {
            // Tentukan path upload dengan benar
            $upload_path = FCPATH . 'uploads/';
            
            // Buat folder uploads jika belum ada
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            // Konfigurasi upload
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 5000; // 5MB in KB
            $config['file_name'] = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['gambar']['name']);
            $config['remove_spaces'] = TRUE;
            
            // Reload library dengan config baru (unload old config dulu)
            if ($this->load->is_loaded('upload')) {
                $this->upload->initialize($config);
            } else {
                $this->load->library('upload', $config);
            }
            
            if ($this->upload->do_upload('gambar')) {
                $upload_data = $this->upload->data();
                $data['gambar'] = $upload_data['file_name'];
            } else {
                $this->session->set_flashdata('error', 'Gagal upload gambar: ' . $this->upload->display_errors());
                redirect('admin/destinasi_tambah');
                return;
            }
        } else {
            $this->session->set_flashdata('error', 'Silakan pilih gambar terlebih dahulu!');
            redirect('admin/destinasi_tambah');
            return;
        }

        if ($this->Destinasi_model->insert_destinasi($data)) {
            $this->session->set_flashdata('success', 'Destinasi berhasil ditambahkan!');
            // Setelah admin menambah destinasi, langsung menuju halaman home user
            redirect('admin/index');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan destinasi ke database!');
            redirect('admin/destinasi_tambah');
        }
    }

    public function destinasi_delete($id) {
        $this->load->model('Destinasi_model');
        
        // Ambil data destinasi untuk mendapatkan nama gambar
        $destinasi = $this->Destinasi_model->get_destinasi_by_id($id);
        
        if ($destinasi) {
            // Hapus gambar dari folder
            if (!empty($destinasi->gambar)) {
                $gambar_path = FCPATH . 'uploads/' . $destinasi->gambar;
                if (file_exists($gambar_path)) {
                    unlink($gambar_path);
                }
            }
            
            // Hapus data dari database
            if ($this->Destinasi_model->delete_destinasi($id)) {
                $this->session->set_flashdata('success', 'Destinasi berhasil dihapus!');
            } else {
                $this->session->set_flashdata('error', 'Gagal menghapus destinasi!');
            }
        } else {
            $this->session->set_flashdata('error', 'Destinasi tidak ditemukan!');
        }
        
        redirect('admin');
    }

    public function destinasi_edit($id) {
        $this->load->model('Destinasi_model');
        
        $data['title'] = 'Edit Destinasi';
        $data['destinasi'] = $this->Destinasi_model->get_destinasi_by_id($id);
        
        if (empty($data['destinasi'])) {
            $this->session->set_flashdata('error', 'Destinasi tidak ditemukan!');
            redirect('admin');
        }
        
        $this->load->view('admin/destinasi_edit', $data);
    }

    public function update_destinasi($id) {
        $this->load->model('Destinasi_model');
        
        $destinasi = $this->Destinasi_model->get_destinasi_by_id($id);
        
        if (empty($destinasi)) {
            $this->session->set_flashdata('error', 'Destinasi tidak ditemukan!');
            redirect('admin');
        }
        
        $data = array(
            'nama_destinasi' => $this->input->post('nama_destinasi'),
            'stock' => $this->input->post('stock'),
            'harga' => $this->input->post('harga')
        );

        // Handle file upload jika ada
        if (!empty($_FILES['gambar']['name'])) {
            $upload_path = FCPATH . 'uploads/';
            
            // Buat folder uploads jika belum ada
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            // Konfigurasi upload
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 5000; // 5MB in KB
            $config['file_name'] = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['gambar']['name']);
            $config['remove_spaces'] = TRUE;
            
            // Initialize upload library
            $this->load->library('upload', $config);
            
            if ($this->upload->do_upload('gambar')) {
                $upload_data = $this->upload->data();
                $new_gambar = $upload_data['file_name'];
                
                // Hapus gambar lama jika ada
                if (!empty($destinasi->gambar)) {
                    $old_gambar_path = $upload_path . $destinasi->gambar;
                    if (file_exists($old_gambar_path)) {
                        unlink($old_gambar_path);
                    }
                }
                
                $data['gambar'] = $new_gambar;
            } else {
                $this->session->set_flashdata('error', 'Gagal upload gambar: ' . $this->upload->display_errors());
                redirect('admin/destinasi_edit/' . $id);
                return;
            }
        }

        if ($this->Destinasi_model->update_destinasi($id, $data)) {
            $this->session->set_flashdata('success', 'Destinasi berhasil diupdate!');
            redirect('admin');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengupdate destinasi!');
            redirect('admin/destinasi_edit/' . $id);
        }
    }
}
