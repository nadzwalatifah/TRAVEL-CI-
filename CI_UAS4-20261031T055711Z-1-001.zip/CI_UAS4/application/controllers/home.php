<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }

    public function index()
    {
        // Tampilkan halaman home dengan daftar destinasi dari database
        $this->load->model('Destinasi_model');
        $data['destinasi'] = $this->Destinasi_model->get_all_destinasi();
        $this->load->view('home', $data);
    }

    private function requireLogin()
    {
        if (!$this->session->userdata('login')) {
            redirect('auth/login');
        }
    }

    public function lombok()
    {
        $this->requireLogin();
        $this->load->view('order');
    }

    public function bali()
    {
        $this->requireLogin();
        $this->load->view('order');
    }

    public function papua()
    {
        $this->requireLogin();
        $this->load->view('order');
    }
}
