<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesanan_model extends CI_Model {

    private $table = 'order'; // sesuaikan nama tabel

    public function get_all_pesanan() {
        return $this->db
            ->order_by('id_order', 'DESC')
            ->get($this->table)
            ->result();
    }

    public function search_pesanan($keyword) {
        $this->db->like('id_order', $keyword);
        $this->db->or_like('id_destinasi', $keyword);
        $this->db->or_like('destinasi', $keyword);
        $this->db->or_like('nama_lengkap', $keyword);

        return $this->db
            ->order_by('id_order', 'DESC')
            ->get($this->table)
            ->result();
    }

    public function get_by_id($id) {
        return $this->db
            ->where('id_order', $id)
            ->get($this->table)
            ->row();
    }

    public function delete($id) {
        return $this->db
            ->where('id_order', $id)
            ->delete($this->table);
    }
}