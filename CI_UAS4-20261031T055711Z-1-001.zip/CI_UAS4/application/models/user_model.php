<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function register($data)
    {
        return $this->db->insert('users', $data);
    }

    public function login($nama, $password)
    {
        return $this->db->get_where('users', [
            'nama' => $nama,
            'password' => $password
        ])->row();
    }

    public function get_role($user_id)
    {
        return $this->db->select('role')->get_where('users', [
            'id' => $user_id
        ])->row();
    }
}
