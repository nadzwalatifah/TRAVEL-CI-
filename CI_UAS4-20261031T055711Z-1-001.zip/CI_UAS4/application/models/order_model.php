<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class order_model extends CI_Model {

    // Fungsi umum untuk menyimpan array data ke tabel 'order'
    public function simpan_data($data)
    {
        // Menggunakan backtick pada 'order' karena 'order' adalah reserved word di SQL
        return $this->db->insert('order', $data);
    }

    /**
     * Fungsi untuk mengambil semua riwayat order
     */
    public function get_all_orders()
    {
        return $this->db->order_by('date', 'DESC')
                        ->get('order')
                        ->result_array();
    }

    /**
     * Fungsi Hapus Order
     */
    public function delete_order($id)
    {
        return $this->db->where('id_order', $id)
                        ->delete('order');
    }

    /**
     * Fungsi Update Status (Contoh mengisi kolom bukti)
     */
    public function update_pembayaran($id)
    {
        return $this->db->where('id_order', $id)
                        ->update('order', ['bukti' => 'PAID']);
    }
}