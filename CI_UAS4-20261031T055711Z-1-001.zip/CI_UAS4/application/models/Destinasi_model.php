<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Destinasi_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_all_destinasi() {
        return $this->db->get('tambah')->result();
    }

    public function get_destinasi_by_id($id) {
        return $this->db->get_where('tambah', ['id' => $id])->row();
    }

    public function insert_destinasi($data) {
        return $this->db->insert('tambah', $data);
    }

    public function update_destinasi($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('tambah', $data);
    }

    public function delete_destinasi($id) {
        return $this->db->delete('tambah', ['id' => $id]);
    }

    public function search_destinasi($keyword) {
        $this->db->like('id', $keyword);
        $this->db->or_like('nama_destinasi', $keyword);
        return $this->db->get('tambah')->result();
    }

    /**
     * Decrement stock atomically. Returns TRUE if stock was decremented, FALSE if insufficient stock.
     * Uses a single UPDATE ... WHERE stock >= ? so it's safe under concurrency.
     */
    public function decrement_stock($id, $qty = 1) {
        $this->db->query("UPDATE tambah SET stock = stock - ? WHERE id = ? AND stock >= ?", array($qty, $id, $qty));
        return ($this->db->affected_rows() > 0);
    }
}
?>
