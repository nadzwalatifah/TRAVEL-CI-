<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class order_model extends CI_Model {

    public function simpan_data($data)
    {
        return $this->db->insert('order', $data);
    }
}