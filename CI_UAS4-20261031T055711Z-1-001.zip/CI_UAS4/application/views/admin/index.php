<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Data Destinasi Wisata</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/index-admin.css">
</head>
<body>
    <?php $this->load->view('navbar-admin'); ?>
    <div class="container">
        <h2>Data Destinasi Wisata</h2>
        
        <div class="header-controls">
            <a href="<?= site_url('admin/destinasi_tambah') ?>" class="tambah">+ Tambah Destinasi</a>
            
            <form method="GET" class="search-box">
                <input type="text" name="cari" placeholder="Cari ID atau nama destinasi..." value="<?= isset($_GET['cari']) ? htmlspecialchars($_GET['cari']) : ''; ?>">
                <button type="submit">Cari</button>
                <a href="<?= site_url('admin') ?>" class="reset">Reset</a>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID Destinasi</th>
                    <th>Nama Destinasi</th>
                    <th>Gambar</th>
                    <th>Stock</th>
                    <th>Harga</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($destinasi)): ?>
                    <?php foreach ($destinasi as $item): ?>
                        <tr>
                            <td><?= $item->id ?></td>
                            <td><?= htmlspecialchars($item->nama_destinasi) ?></td>
                            <td>
                                <?php if (!empty($item->gambar)): ?>
                                    <img src="<?= base_url('uploads/' . $item->gambar) ?>" alt="<?= $item->nama_destinasi ?>" class="gambar-destinasi">
                                <?php else: ?>
                                    <span style="color: #999;">Tidak ada gambar</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $item->stock ?></td>
                            <td>Rp <?= number_format($item->harga, 0, ',', '.') ?></td>
                            <td class="action-buttons">
                                <a class="edit" href="<?= site_url('admin/destinasi_edit/' . $item->id) ?>">Edit</a>
                                <a class="hapus" href="<?= site_url('admin/destinasi_delete/' . $item->id) ?>" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="no-data">Data destinasi tidak ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>