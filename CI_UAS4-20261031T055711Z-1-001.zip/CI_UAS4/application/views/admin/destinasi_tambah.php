<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Destinasi - Admin Dashboard</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/tambah.css">

</head>
<body>
    <?php $this->load->view('navbar-admin'); ?>
    <div class="container">
        <h2>Tambah Destinasi Wisata</h2>
        
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert success">
                <?= $this->session->flashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert error">
                <?= $this->session->flashdata('error') ?>
            </div>
        <?php endif; ?>
        
        <form action="<?= site_url('admin/store_destinasi') ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nama_destinasi">Nama Destinasi <span class="required">*</span></label>
                <input type="text" id="nama_destinasi" name="nama_destinasi" placeholder="Masukkan nama destinasi" required>
            </div>
            
             <div class="form-group">
                <label for="gambar">Gambar Destinasi <span class="required">*</span></label>
                <input type="file" id="gambar" name="gambar" accept="image/*" required>
                <small>Format: JPG, JPEG, PNG, GIF (Max 5MB)</small>
            </div>

            <div class="form-group">
                <label for="stock">Stock <span class="required">*</span></label>
                <input type="number" id="stock" name="stock" min="0" placeholder="Masukkan jumlah stock" required>
            </div>
            
            <div class="form-group">
                <label for="harga">Harga (Rp) <span class="required">*</span></label>
                <input type="number" id="harga" name="harga" min="0" step="1000" placeholder="Contoh: 2500000" required>
            </div>
            
           
            
            <div class="buttons">
                <button type="submit">Tambah Destinasi</button>
                <a href="<?= site_url('admin') ?>" class="btn-kembali">BACK</a>
            </div>
        </form>
    </div>
</body>
</html>