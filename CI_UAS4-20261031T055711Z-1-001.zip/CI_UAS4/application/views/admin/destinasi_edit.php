<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Destinasi - Admin Dashboard</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/edit.css">
    
</head>
<body>
    <?php $this->load->view('navbar-admin'); ?>
    
    <div class="container">
        <h2>Edit Destinasi Wisata</h2>
        
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert success">
                <?= $this->session->flashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert error">
                <?= $this->session->flashdata('error') ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($destinasi)): ?>
            <form action="<?= site_url('admin/update_destinasi/' . $destinasi->id) ?>" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="nama_destinasi">Nama Destinasi <span class="required">*</span></label>
                    <input type="text" id="nama_destinasi" name="nama_destinasi" placeholder="Masukkan nama destinasi" value="<?= htmlspecialchars($destinasi->nama_destinasi) ?>" required>
                </div>
                
                
                <div class="form-group">
                    <label for="stock">Stock <span class="required">*</span></label>
                    <input type="number" id="stock" name="stock" min="0" placeholder="Masukkan jumlah stock" value="<?= $destinasi->stock ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="harga">Harga (Rp) <span class="required">*</span></label>
                    <input type="number" id="harga" name="harga" min="0" step="1000" placeholder="Contoh: 2500000" value="<?= $destinasi->harga ?>" required>
                </div>
                
                <div class="form-group">
                   
                    <?php if (!empty($destinasi->gambar)): ?>
                        <div class="current-image">
                            <p><strong>Gambar Saat Ini:</strong></p>
                            <img src="<?= base_url('uploads/' . $destinasi->gambar) ?>" alt="<?= $destinasi->nama_destinasi ?>">
                        </div>
                    <?php endif; ?>
                    <label style="margin-top: 1rem; display: block;">Ganti Gambar (Opsional)</label>
                    <input type="file" id="gambar" name="gambar" accept="image/*">
                    <small>Format: JPG, JPEG, PNG, GIF (Max 5MB). Biarkan kosong jika tidak ingin mengganti gambar.</small>
                </div>
                
                <div class="buttons">
                    <button type="submit">Update Destinasi</button>
                    <a href="<?= site_url('admin') ?>" class="btn-kembali">BACK</a>
                </div>
            </form>
        <?php else: ?>
            <div style="text-align: center; padding: 2rem; color: #999;">
                <p>Data destinasi tidak ditemukan.</p>
                <a href="<?= site_url('admin') ?>" class="btn-kembali">Back To Dashboard</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>