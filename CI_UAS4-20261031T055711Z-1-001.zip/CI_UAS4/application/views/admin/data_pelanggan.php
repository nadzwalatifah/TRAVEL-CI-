<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Admin - Data Pesanan</title>
  <link rel="stylesheet" href="/CI_UAS4/assets/css/pelanggan.css">

</head>
<body>
  <?php $this->load->view('navbar-data'); ?>
  <div class="container">
    <h2>Data Pelanggan (Admin)</h2>
    
    <div class="header-controls">
      
      <form method="GET" class="search-box">
        <input type="text" name="cari" placeholder="Cari ID Order, ID Destinasi, atau Nama..." value="<?php echo isset($_GET['cari']) ? htmlspecialchars($_GET['cari']) : ''; ?>">
        <button type="submit">Cari</button>
        <a href="<?= site_url('admin_pelanggan') ?>" class="reset">Reset</a>
      </form>
    </div>

    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>ID Order</th>
            <th>ID Destinasi</th>
            <th>Waktu Transaksi</th>
            <th>Nama Lengkap</th>
            <th>Email</th>
            <th>No HP</th>
            <th>Jenis Kelamin</th>
            <th>Tgl Lahir</th>
            <th>Destinasi</th>
            <th>Tgl Terbang</th>
            <th>Tiket</th>
            <th>Metode</th>
            <th>Bukti</th>
            <th>Total</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php if (!empty($pesanan)): ?>
    <?php foreach ($pesanan as $row): ?>
        <tr>
            <td><b><?= $row->id_order ?></b></td>
            <td><?= $row->id_destinasi ?></td>
            <td><?= $row->date ?></td>
            <td><?= htmlspecialchars($row->nama_lengkap) ?></td>
            <td><?= $row->email ?></td>
            <td><?= $row->no_hp ?></td>
            <td><?= $row->jenis_kelamin ?></td>
            <td><?= $row->tbt ?></td>
            <td><?= $row->destinasi ?></td>
            <td><?= $row->tanggal_penerbangan ?></td>
            <td><?= $row->jumlah_tiket ?></td>
            <td><?= $row->metode_pembayaran ?></td>
            <td>
    <?php if (!empty($row->bukti)): ?>
        <?= htmlspecialchars($row->bukti) ?>
    <?php else: ?>
        <span style="color:#999;">Tidak ada bukti</span>
    <?php endif; ?>
</td>
            <td>Rp <?= number_format($row->total,0,',','.') ?></td>
            <td>
                <a class="btn-hapus"
                   href="<?= site_url('admin_pelanggan/delete/'.$row->id_order) ?>"
                   onclick="return confirm('Hapus data ini?')">
                   Hapus
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="15" style="text-align:center;">Data tidak ditemukan</td>
    </tr>
<?php endif; ?>
</tbody>
      </table>
    </div>
  </div>

</body>
</html>