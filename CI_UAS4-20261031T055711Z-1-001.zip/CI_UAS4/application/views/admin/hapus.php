<?php 
include 'koneksi.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_destinasi = mysqli_real_escape_string($koneksi, $_POST['nama_destinasi']);
    $stock = intval($_POST['stock']);
    $harga = floatval($_POST['harga']);
    
    // Upload gambar
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "uploads/";
        
        // Buat folder uploads jika belum ada
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        // Validasi file
        $allowed_extensions = array("jpg", "jpeg", "png", "gif");
        
        if (!in_array($file_extension, $allowed_extensions)) {
            $error = "Format file tidak diizinkan. Hanya JPG, JPEG, PNG, GIF.";
        } else if ($_FILES["gambar"]["size"] > 5000000) {
            $error = "Ukuran file terlalu besar. Maksimal 5MB.";
        } else {
            if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                // Insert ke database
                $query = "INSERT INTO destinasi (nama_destinasi, gambar, stock, harga) 
                         VALUES ('$nama_destinasi', '$new_filename', $stock, $harga)";
                
                if (mysqli_query($koneksi, $query)) {
                    $success = "Data berhasil ditambahkan!";
                    header("refresh:2;url=index.php");
                } else {
                    $error = "Gagal menyimpan data: " . mysqli_error($koneksi);
                }
            } else {
                $error = "Gagal upload gambar.";
            }
        }
    } else {
        $error = "Silakan pilih gambar!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Destinasi</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body { 
      font-family: Arial, sans-serif; 
      background-color: #f5f5f5;
      padding: 20px;
    }
    
    .container {
      max-width: 600px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #333;
    }
    
    input, select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
    }
    
    .required {
      color: #dc3545;
    }
    
    .btn-group {
      display: flex;
      gap: 10px;
      margin-top: 30px;
    }
    
    button, .btn {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: 600;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }
    
    .btn-simpan {
      background: #28a745;
      color: white;
    }
    
    .btn-simpan:hover {
      background: #218838;
    }
    
    .btn-kembali {
      background: #6c757d;
      color: white;
    }
    
    .btn-kembali:hover {
      background: #5a6268;
    }
    
    .alert {
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
      text-align: center;
    }
    
    .alert-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    
    .alert-error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Tambah Destinasi Baru</h2>
    
    <?php if ($success): ?>
      <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
      <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label>Nama Destinasi <span class="required">*</span></label>
        <input type="text" name="nama_destinasi" required placeholder="Masukkan nama destinasi">
      </div>
      
      <div class="form-group">
        <label>Gambar <span class="required">*</span></label>
        <input type="file" name="gambar" accept="image/*" required>
        <small style="color: #666;">Format: JPG, JPEG, PNG, GIF (Max 5MB)</small>
      </div>
      
      <div class="form-group">
        <label>Stock <span class="required">*</span></label>
        <input type="number" name="stock" required min="0" placeholder="Jumlah paket tersedia">
      </div>
      
      <div class="form-group">
        <label>Harga (Rp) <span class="required">*</span></label>
        <input type="number" name="harga" required min="0" step="1000" placeholder="Contoh: 2500000">
      </div>
      
      <div class="btn-group">
        <button type="submit" class="btn-simpan">Simpan</button>
        <a href="<?php echo site_url('admin/admin'); ?>" class="btn btn-kembali">Kembali</a>      </div>
      </div>
    </form>
  </div>

</body>
</html>