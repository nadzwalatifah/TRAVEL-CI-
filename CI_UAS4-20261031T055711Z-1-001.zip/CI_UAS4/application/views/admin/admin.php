<?php include 'koneksi.php'; ?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Destinasi Wisata</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body { 
      font-family: Arial, sans-serif; 
      background-color: #f5f5f5;
      padding: 20px;
    }
    
    .container {
      max-width: 1400px;
      margin: 0 auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    h2 { 
      text-align: center; 
      color: #333;
      margin-bottom: 30px;
      font-size: 2em;
    }
    
    .header-controls {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      flex-wrap: wrap;
      gap: 15px;
    }
    
    .search-box {
      display: flex;
      gap: 10px;
      align-items: center;
    }
    
    .search-box input {
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      width: 300px;
      font-size: 14px;
    }
    
    .search-box button {
      padding: 10px 20px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: 600;
    }
    
    .search-box button:hover {
      background: #0056b3;
    }
    
    table { 
      border-collapse: collapse; 
      width: 100%;
      margin-top: 20px;
    }
    
    th, td { 
      border: 1px solid #ddd; 
      padding: 12px; 
      text-align: left; 
    }
    
    th { 
      background: #333; 
      color: white;
      font-weight: 600;
    }
    
    tbody tr:hover {
      background-color: #f9f9f9;
    }
    
    .gambar-destinasi {
      width: 100px;
      height: 100px;
      object-fit: cover;
      border-radius: 5px;
    }
    
    a { 
      text-decoration: none; 
      padding: 8px 15px; 
      border-radius: 5px; 
      display: inline-block;
      margin: 2px;
      font-size: 14px;
      font-weight: 600;
    }
    
    .tambah { 
      background: #28a745; 
      color: white; 
    }
    
    .tambah:hover {
      background: #218838;
    }
    
    .edit { 
      background: #ffc107; 
      color: black; 
    }
    
    .edit:hover {
      background: #e0a800;
    }
    
    .hapus { 
      background: #dc3545; 
      color: white; 
    }
    
    .hapus:hover {
      background: #c82333;
    }
    
    .reset { 
      background: #6c757d; 
      color: white; 
    }
    
    .reset:hover {
      background: #5a6268;
    }
    
    .no-data {
      text-align: center;
      padding: 30px;
      color: #999;
      font-style: italic;
    }
    
    .action-buttons {
      display: flex;
      gap: 5px;
      flex-wrap: wrap;
    }
    
    @media (max-width: 768px) {
      .header-controls {
        flex-direction: column;
        align-items: stretch;
      }
      
      .search-box {
        flex-direction: column;
      }
      
      .search-box input {
        width: 100%;
      }
      
      table {
        font-size: 12px;
      }
      
      .gambar-destinasi {
        width: 60px;
        height: 60px;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Data Destinasi Wisata</h2>
    
    <div class="header-controls">
      <a href="destinasi_tambah.php" class="tambah">+ Tambah Destinasi</a>
      
      <form method="GET" class="search-box">
        <input type="text" name="cari" placeholder="Cari nama destinasi..." value="<?php echo isset($_GET['cari']) ? htmlspecialchars($_GET['cari']) : ''; ?>">
        <button type="submit">Cari</button>
        <a href="<?php echo site_url('admin/admin'); ?>" class="reset">Reset</a>
      </form>
    </div>

    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Destinasi</th>
          <th>Gambar</th>
          <th>Stock</th>
          <th>Harga</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        $cari = isset($_GET['cari']) ? $_GET['cari'] : '';

        // Jika ada pencarian
        if ($cari != '') {
            $query = mysqli_query($koneksi,
                "SELECT * FROM destinasi 
                 WHERE nama_destinasi LIKE '%$cari%' 
                 ORDER BY nama_destinasi ASC"
            );
        } else {
            // Tampilkan semua data
            $query = mysqli_query($koneksi,
                "SELECT * FROM destinasi ORDER BY id DESC"
            );
        }

        $hasil = mysqli_num_rows($query);

        if ($hasil > 0) {
            while ($data = mysqli_fetch_array($query)) {
                $harga_format = number_format($data['harga'], 0, ',', '.');
                echo "
                <tr>
                  <td>{$no}</td>
                  <td>{$data['nama_destinasi']}</td>
                  <td><img src='uploads/{$data['gambar']}' alt='Gambar Destinasi' class='gambar-destinasi'></td>
                  <td>{$data['stock']}</td>
                  <td>Rp {$harga_format}</td>
                  <td class='action-buttons'>
                    <a class='edit' href='edit.php?id={$data['id']}'>Edit</a>
                    <a class='hapus' href='hapus.php?id={$data['id']}' onclick='return confirm(\"Yakin hapus data ini?\")'>Hapus</a>
                  </td>
                </tr>
                ";
                $no++;
            }
        } else {
            echo "
            <tr>
              <td colspan='6' class='no-data'>Data tidak ditemukan.</td>
            </tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>