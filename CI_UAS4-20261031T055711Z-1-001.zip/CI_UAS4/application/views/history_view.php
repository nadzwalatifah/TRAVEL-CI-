<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History - CodeIgniter</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/order.css">
    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">
</head>
<body>
    <?php $this->load->view('navbar'); ?>
    <div id="navbar-placeholder"></div>
    <div class="container">
        <div class="page-title-wrapper">
            <div class="page-title-card"><h1>Riwayat Pemesanan</h1></div>
        </div>

        <?php if($this->session->flashdata('msg')): ?>
            <div class="alert-success">
                <?= $this->session->flashdata('msg'); ?>
            </div>
        <?php endif; ?>

        <div class="order-list">
            <?php if(!empty($orders)): ?>
                <?php foreach($orders as $o): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <span class="order-number">#ORD-<?= $o['id_order']; ?></span>
                            <span class="status-sudah-bayar">Sudah Bayar</span>
                        </div>

                        <div class="order-details">
                            <div><small>Nama:</small><br><strong><?= $o['nama_lengkap']; ?></strong></div>
                            <div><small>Destinasi:</small><br><strong><?= $o['destinasi']; ?></strong></div>
                            <div><small>Tanggal:</small><br><strong><?= $o['tanggal_penerbangan']; ?></strong></div>
                            <div><small>Tiket:</small><br><strong><?= $o['jumlah_tiket']; ?> Tiket</strong></div>
                        </div>

                        <div class="order-total">
                            Total: Rp. <?= number_format($o['total'], 0, ',', '.'); ?>
                        </div>

                        <div class="order-actions">
                            <a href="<?= site_url('history/download_tiket/'.$o['id_order']); ?>" class="btn btn-download">
                                Download Tiket
                            </a>

                            <a href="<?= site_url('history/hapus/'.$o['id_order']); ?>" class="btn btn-delete" onclick="return confirm('Hapus data?')">Hapus</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center;">Tidak ada riwayat pemesanan.</p>
            <?php endif; ?>
        </div>

        <div style="text-align: center; margin-top: 20px;">
            <a href="<?= site_url('home'); ?>" class="btn btn-secondary">BACK</a>
        </div>
    </div>

    <?php $this->load->view('footer'); ?>
</body>
</html>