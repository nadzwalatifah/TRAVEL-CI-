<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">

    <style>
        body {
            margin: 0;
            padding-top: 70px; /* Memberi ruang agar konten tidak tertutup navbar */
        }

        .navbar {
            position: fixed !important; /* MENGUNCI NAVBAR */
            top: 0;                     /* Tempel di atas */
            left: 0;                    /* Tempel di kiri */
            width: 100%;                /* Lebar penuh */
            z-index: 9999;              /* Di atas semua elemen lain */
            background-color: #333;     /* Pastikan warna terlihat */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-sizing: border-box;     /* Agar padding tidak merusak lebar */
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <a href="<?= site_url('home') ?>" style="color: white; text-decoration: none; font-weight: bold; font-size: 24px;">EXPLORE BEYOND</a>
    </div>

    <ul class="nav-links">
        <?php 
            $is_login = $this->session->userdata('login');
            if ($is_login == true) : 
        ?>
            <li><a href="<?= site_url('history') ?>" style="color: white; text-decoration: none;">History</a></li>
            <li><a href="<?= site_url('contact') ?>" style="color: white; text-decoration: none;">Contact Us</a></li>
            <li>
                <a href="<?= site_url('auth/logout') ?>" 
                   style="color: white; text-decoration: none;"
                   onclick="return confirm('Yakin logout?')">
                   Logout
                </a>
            </li>
        <?php else : ?>
            <li><a href="<?= site_url('auth/login') ?>" style="color: white; text-decoration: none;">Login</a></li>
            <li><a href="<?= site_url('auth/register') ?>" style="color: white; text-decoration: none;">Register</a></li>
            <li><a href="<?= site_url('contact') ?>" style="color: white; text-decoration: none;">Contact Us</a></li>
        <?php endif; ?>
    </ul>
</nav>
</body>
</html>