<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EXPLORE BEYOND</title>    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">    <link rel="stylesheet" href="<?= base_url('assets/css/login_register.css') ?>">
</head>
<body>

<div class="container">
    <h3 class="title">EXPLORE BEYOND</h3>

    <div class="card">
        <form action="<?= site_url('auth/home') ?>" method="post">
            <h3>Login</h3>

            <div class="signup-link">
                <span>You Don't have an Account Yet?</span>
                <p><a href="<?= site_url('auth/register') ?>">Register Here</a></p>
            </div>

            <label for="nama">Name:</label>
            <input type="text" id="nama" name="nama" placeholder="" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="" placeholder="Enter Password" required>

            <div class="buttons">
                <button type="submit">Login</button>
                <a href="<?= site_url('home') ?>" class="btn-back">Back</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>
