<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Order Ticket</title>
  <link rel="stylesheet" href="/CI_UAS4/assets/css/order.css">
  <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">
</head>
<body>
  <?php $this->load->view('navbar'); ?>
    <div id="navbar-placeholder"></div>
  <div class="container">
    <form id="orderForm" action="<?php echo site_url('order/simpan'); ?>" method="POST">
      <form id="orderForm" action="<?php echo site_url('order/simpan'); ?>" method="POST" enctype="multipart/form-data">
      <div class="row">
         
        <div class="card card-order">
          <div class="card-body">
            <h4>Order Ticket</h4>

            <div class="form-group">
              <label>Nama Lengkap *</label>
              <input type="text" name="nama_lengkap" required placeholder="Masukkan nama lengkap" />
            </div>

            <div class="form-group">
              <label>Email *</label>
              <input type="email" name="email" required placeholder="contoh@email.com" />
            </div>

            <div class="form-group">
              <label>No. HP *</label>
              <input type="tel" name="no_hp" required placeholder="08xxxxxxxxxx" />
            </div>

            <div class="form-group">
              <label>Jenis Kelamin *</label>
              <select name="jenis_kelamin" required>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <div class="form-group">
              <label>Tanggal Lahir *</label>
              <input type="date" name="tbt" required />
            </div>

            <div class="form-group">
              <label>Pilih Tujuan *</label>
              <select id="destinationSelect" name="destinasi" required>
                <option value="">Pilih destinasi</option>
                <?php if (!empty($destinasi)): ?>
                  <?php foreach ($destinasi as $d): ?>
                    <option value="<?php echo htmlspecialchars($d->nama_destinasi); ?>" data-id="<?php echo $d->id; ?>" data-price="<?php echo $d->harga; ?>" data-stock="<?php echo $d->stock; ?>"><?php echo htmlspecialchars($d->nama_destinasi); ?> - Rp. <?php echo number_format($d->harga,0,',','.'); ?></option>
                  <?php endforeach; ?>
                <?php endif; ?>
              </select>
              <input type="hidden" name="id_destinasi" id="id_destinasi_val" value="">
            </div>

            <div class="form-group">
              <label>Tanggal Penerbangan *</label>
              <input type="date" name="tanggal_penerbangan" required min="<?php echo date('Y-m-d'); ?>" />
            </div>

           
            <div class="form-group">
              <label>Metode Pembayaran *</label>
              <select name="metode_pembayaran" required>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="E-Wallet">E-Wallet</option>
                <option value="BCA">BCA</option>
                <option value="Mandiri">Mandiri</option>
              </select>
            </div>

            <div class="form-group">
              <label>Jumlah Tiket *</label>
              <input type="number" id="quantityInput" name="jumlah_tiket" value="1" min="1" max="50" required />
            </div>

            <input type="hidden" id="totalInput" name="total" value="0">

            <div class="form-group">
              <label>Upload Bukti Pembayaran *</label>
              <input type="file" name="bukti" accept="image/*" required />
              <small style="color: #ffffff;">Format: JPG, PNG, JPEG. Maks 2MB.</small>
            </div>

            <div class="total-price" id="totalPriceDisplay">Total: Rp. 0</div>
            
            <button type="submit">Order Now</button>
            <a href="<?php echo site_url('home'); ?>" class="btn-back">Back</a>
          </div>
        </div>
      </div>
    </form>
  </div>
  <script src="/CI_UAS4/assets/js/order.js"></script>
</body>
</html>