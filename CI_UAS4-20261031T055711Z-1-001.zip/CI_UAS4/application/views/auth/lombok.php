<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Order Ticket</title>
  <style>
    * { box-sizing: border-box; }
    body { background-color: #eae7e7a5; font-family: Arial, sans-serif; margin: 0; padding: 0; min-height: 100vh; display: flex; flex-direction: column; }
    .container { max-width: 1200px; margin: 2rem auto; padding: 0 1rem; flex-grow: 1; }
    .row { display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center; }
    .card { background-color: #ffffffa1; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; flex: 1 1 300px; max-width: 400px; display: flex; flex-direction: column; }
    .card img { width: 100%; height: 250px; display: block; object-fit: cover; }
    .card-body { padding: 1.5rem; flex-grow: 1; display: flex; flex-direction: column; }
    .card-body h4 { font-family: Georgia, serif; margin: 0 0 1.5rem; text-align: center; font-size: 1.5rem; color: #333; }
    .form-group { margin-bottom: 1rem; }
    label { display: block; font-weight: bold; color: #333; margin-bottom: 0.3rem; font-size: 0.9rem; }
    input, select { width: 100%; padding: 0.6rem 0.75rem; font-size: 0.95rem; border: 1px solid #ccc; border-radius: 5px; }
    .total-price { margin: 1.5rem 0; padding: 1rem; font-size: 1.3rem; font-weight: bold; color: #28a745; text-align: center; background-color: #f8f9fa; border-radius: 5px; }
    button { background-color: #007bff; color: white; padding: 0.75rem; border-radius: 5px; border: none; cursor: pointer; width: 100%; font-size: 1rem; transition: 0.3s; }
    button:hover { background-color: #0056b3; }
    .btn-back { display: block; text-align: center; padding: 0.75rem; background-color: #343a40; color: white; text-decoration: none; border-radius: 5px; margin-top: 10px; }
    .card-order { flex: 0 0 800px; max-width: 800px; }
  </style>
</head>
<body>
  <div class="container">
    <form id="orderForm" action="<?php echo site_url('order/simpan'); ?>" method="POST">
      <div class="row">
        <div class="card"><img src="/CI_UAS4/assets/image/lb1.jpg" alt="Lombok 1"></div>
        <div class="card"><img src="/CI_UAS4/assets/image/lb2.jpg" alt="Lombok 2"></div>
        <div class="card"><img src="/CI_UAS4/assets/image/lb2.jpg" alt="Lombok 3"></div>
        
        <div class="card card-order">
          <div class="card-body">
            <h4>Order Ticket</h4>

            <div class="form-group">
              <label>Nama Lengkap *</label>
              <input type="text" name="nama_lengkap" required placeholder="Masukkan nama lengkap" />
            </div>

            <div class="form-group">
              <label>Email *</label>
              <input type="email" name="emaill" required placeholder="contoh@email.com" />
            </div>

            <div class="form-group">
              <label>No. HP *</label>
              <input type="tel" name="no_hp" required placeholder="08xxxxxxxxxx" />
            </div>

            <div class="form-group">
              <label>Jenis Kelamin *</label>
              <select name="jenis_kelamin" required>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <div class="form-group">
              <label>Tanggal Lahir *</label>
              <input type="date" name="tbt" required />
            </div>

            <div class="form-group">
              <label>Pilih Tujuan *</label>
              <select id="destinationSelect" name="destinasi" required>
                <option value="">Pilih destinasi</option>
                <option value="lombok" data-id="1" data-price="1000000">Lombok - Rp. 1.000.000</option>
                <option value="bali" data-id="2" data-price="1500000">Bali - Rp. 1.500.000</option>
                <option value="papua" data-id="3" data-price="2500000">Papua - Rp. 2.500.000</option>
              </select>
              <input type="hidden" name="id_destinasi" id="id_destinasi_val" value="">
            </div>

            <div class="form-group">
              <label>Metode Pembayaran *</label>
              <select name="metode_pembayaran" required>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="E-Wallet">E-Wallet</option>
                <option value="BCA">BCA</option>
                <option value="Mandiri">Mandiri</option>
              </select>
            </div>

            <div class="form-group">
              <label>Jumlah Tiket *</label>
              <input type="number" id="quantityInput" name="jumlah_tiket" value="1" min="1" max="50" required />
            </div>

            <div class="total-price" id="totalPriceDisplay">Total: Rp. 0</div>
            
            <button type="submit">Order Now</button>
            <a href="<?php echo site_url('auth/home'); ?>" class="btn-back">Back</a>
          </div>
        </div>
      </div>
    </form>
  </div>

  <script>
    const destSelect = document.getElementById('destinationSelect');
    const qtyInput = document.getElementById('quantityInput');
    const totalDisplay = document.getElementById('totalPriceDisplay');
    const idDestVal = document.getElementById('id_destinasi_val');

    function calculate() {
      const selected = destSelect.options[destSelect.selectedIndex];
      const price = selected.getAttribute('data-price') || 0;
      const id = selected.getAttribute('data-id') || "";
      const qty = qtyInput.value;
      
      idDestVal.value = id; // Set id_destinasi ke hidden input
      const total = price * qty;
      totalDisplay.textContent = 'Total: Rp. ' + total.toLocaleString('id-ID');
    }

    destSelect.addEventListener('change', calculate);
    qtyInput.addEventListener('input', calculate);

    document.getElementById('orderForm').onsubmit = function() {
        return confirm("Apakah Anda yakin ingin melakukan pemesanan ini?");
    };
  </script>
</body>
</html>