<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME - EXPLORE BEYOND</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/utama.css">
</head>
<body>
    <?php $this->load->view('navbar'); ?>
    <div id="navbar-placeholder"></div>
    <img src="/CI_UAS4/assets/image/er.jpg" alt="Explore Beyond Header" class="header-img">

    <div class="container">
        <h2>PILIH TUJUAN</h2>
        <div class="row">
            <a href="<?php echo site_url('order'); ?>" class="col">
                <div class="card">
                    <img src="/CI_UAS4/assets/image/kuta.jpeg" class="card-img" alt="lombok">
                    <div class="card-body">
                        <p class="card-title">LOMBOK</p>
                        <p class="card-price">Rp. 1.000.000</p>
                    </div>
                </div>
            </a>
            <a href="<?php echo site_url('order'); ?>" class="col">
                <div class="card">
                    <img src="/CI_UAS4/assets/image/ubud.jpeg" class="card-img" alt="Bali">
                    <div class="card-body">
                        <p class="card-title">BALI</p>
                        <p class="card-price">Rp. 8.000.000</p>
                    </div>
                </div>
            </a>
            <a href="<?php echo site_url('order'); ?>" class="col">
                <div class="card">
                    <img src="/CI_UAS4/assets/image/ampat.jpeg" class="card-img" alt="Papua">
                    <div class="card-body">
                        <p class="card-title">PAPUA</p>
                        <p class="card-price">Rp. 3.000.000</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
    
<script src="js/nav.js"></script> 
    <script src="js/loadnavbar.js"></script>
    <script src="infologin.js"></script> 
</body>
</html>