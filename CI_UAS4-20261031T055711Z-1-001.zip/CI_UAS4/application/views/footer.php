<footer class="site-footer">
    <div class="container">
        <h2 class="footer-title">EXPLORE BEYOND</h2>
        <p class="footer-description">
            EXPLORE BEYOND is a blog website where you will find great tutorials on web design and development. Here each tutorial is beautifully described step by step with the required source code.
        </p>
         <link rel="stylesheet" href="<?= base_url('assets/css/footer.css'); ?>">
        <div class="social-media">
            <div class="social-item">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="4" width="20" height="16" rx="2"/>
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                </svg>
                <a href="mailto:info@explorebeyond.com"
           style="color:white; text-decoration:none;">
            info@explorebeyond.com
        </a>
            </div>
            <div class="social-item">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
                </svg>
                <a href="https://www.instagram.com/si24aaaaaaaaaa_?igsh=M3dhdHM2Y3BhM3Nm&utm_source=qr"
           target="_blank"
           style="color:white; text-decoration:none;">
            @explorebeyond
        </a>
            </div>
            <div class="social-item">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                <a href="https://wa.me/6281234567890"
           target="_blank"
           style="color:white; text-decoration:none;">
            0813-1710-9547
        </a>
            </div>
        </div>
        <div class="footer-copyright">
            <p>&copy; <?= date('Y'); ?> <strong>EXPLORE BEYOND</strong>. All rights reserved. &nbsp; <a href="<?= site_url('contactus'); ?>">Contact Us</a></p>
        </div>
    </div>
</footer>

