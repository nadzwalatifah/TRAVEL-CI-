<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/contact.css'); ?>">
    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">
</head>
<body>
<?php $this->load->view('navbar'); ?>
<div class="contact-wrapper">
    <div class="contact-info">
        <center><h1>GET IN TOUCH</h1></center>
        <p>
            Website kami merupakan platform pemesanan tiket trip yang menyediakan berbagai pilihan perjalanan wisata dengan mudah, cepat, dan aman. Melalui website ini, pengguna dapat menemukan informasi lengkap mengenai destinasi wisata, harga tiket dalam setiap trip. Kami berkomitmen untuk memberikan pengalaman perjalanan terbaik dengan layanan profesional, sistem pemesanan yang praktis, dan dukungan pelanggan yang siap membantu, sehingga setiap perjalanan Anda menjadi lebih nyaman, menyenangkan, dan berkesan.
        </p> <hr>

        <ul class="contact-list">

    <!-- EMAIL -->
    <li>
         <img src="<?= base_url('assets/image/email.png'); ?>" class="icon">
        <a href="mailto:info@explorebeyond.com"
           style="color:white; text-decoration:none;">
            info@explorebeyond.com
        </a>
    </li>

    <!-- INSTAGRAM -->
    <li>
        <img src="<?= base_url('assets/image/ig.png'); ?>" class="icon">
        <a href="https://www.instagram.com/si24aaaaaaaaaa_?igsh=M3dhdHM2Y3BhM3Nm&utm_source=qr"
           target="_blank"
           style="color:white; text-decoration:none;">
            @explorebeyond
        </a>
    </li>

    <!-- WHATSAPP -->
    <li>
          <img src="<?= base_url('assets/image/wa.png'); ?>" class="icon">
        <a href="https://wa.me/6281234567890"
           target="_blank"
           style="color:white; text-decoration:none;">
            0813-1710-9547
        </a>
    </li>
</ul>

    </div>



</div>


    <?php $this->load->view('footer'); ?>
</body>
</html>
