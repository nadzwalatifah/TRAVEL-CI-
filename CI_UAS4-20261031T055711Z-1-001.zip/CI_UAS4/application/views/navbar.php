<nav class="navbar">
    <div class="logo">
        <a href="<?= site_url('home') ?>" style="color: white; text-decoration: none; font-weight: bold; font-size: 24px;">EXPLORE BEYOND</a>
    </div>

    <ul class="nav-links">
        <?php 
            $is_login = $this->session->userdata('login');
            if ($is_login == true) : 
        ?>
            <li><a href="<?= site_url('history') ?>" style="color: white; text-decoration: none;">History</a></li>
            <li><a href="<?= site_url('contactus') ?>" style="color: white; text-decoration: none;">Contact Us</a></li>
            <li>
                <a href="<?= site_url('auth/logout') ?>" 
                   style="color: white; text-decoration: none;"
                   onclick="return confirm('Yakin logout?')">
                   Logout
                </a>
            </li>
        <?php else : ?>
            <li><a href="<?= site_url('auth/login') ?>" style="color: white; text-decoration: none;">Login</a></li>
            <li><a href="<?= site_url('auth/register') ?>" style="color: white; text-decoration: none;">Register</a></li>
            <li><a href="<?= site_url('contactus') ?>" style="color: white; text-decoration: none;">Contact Us</a></li>
        <?php endif; ?>
    </ul>
</nav>  