<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EXPLORE BEYOND</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/login_register.css') ?>">
</head>
<body>

<div class="container">
    <h3 class="title">EXPLORE BEYOND</h3>

    <div class="card">
        <?php if ($this->session->flashdata('login_error')): ?>
            <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; border: 1px solid #f5c6cb;">
                <strong>⚠️ Login Gagal!</strong><br>
                <?= $this->session->flashdata('login_error') ?>
            </div>
        <?php endif; ?>
        
        <form action="<?= site_url('auth/login') ?>" method="post">
            <h3>Login</h3>

            <div class="signup-link">
                <span>You Don't have an Account Yet?</span>
                <p><a href="<?= site_url('auth/register') ?>">Register Here</a></p>
            </div>

            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter Username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter Password" required minlength="8">
            <span id="passwordError" style="color: red;"></span>

            <div class="buttons">
                <button type="submit">Login</button>
                <a href="<?= site_url('home') ?>" class="btn-back">Back</a>
            </div>
        </form>
    </div>
</div>

    <script src="<?= base_url('assets/js/login.js') ?>"></script>
</body>
</html>
