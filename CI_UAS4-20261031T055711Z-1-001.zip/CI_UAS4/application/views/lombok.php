<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Order Ticket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?= base_url('assets/css/order.css'); ?>">
</head>
<body>

<?php $this->load->view('navbar'); ?>

<div class="container">

<form id="orderForm"
      action="<?= site_url('order/simpan'); ?>"
      method="POST"
      enctype="multipart/form-data">

<div class="row">

    <!-- CARD GAMBAR -->
    <div class="card"><img src="<?= base_url('assets/image/lb1.jpg'); ?>"></div>
    <div class="card"><img src="<?= base_url('assets/image/lb2.jpg'); ?>"></div>
    <div class="card"><img src="<?= base_url('assets/image/lb3.jpg'); ?>"></div>

    <!-- CARD INFO -->
    <div class="card card-info">
        <div class="card-body">
            <h4>Informasi Trip</h4>
            <p>
                Website kami menyediakan layanan pemesanan tiket trip dengan proses
                yang mudah dan aman. Pastikan data Anda benar sebelum melakukan pemesanan.
                Tiket yang sudah dibayar tidak dapat dibatalkan.
            </p>
        </div>
    </div>

    <!-- CARD ORDER -->
    <div class="card card-order">
        <div class="card-body">
            <h4>Order Ticket</h4>

            <div class="form-group">
                <label>Nama Lengkap *</label>
                <input type="text" name="nama_lengkap" required>
            </div>

            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>No. HP *</label>
                <input type="tel" name="no_hp" required>
            </div>

            <div class="form-group">
                <label>Jenis Kelamin *</label>
                <select name="jenis_kelamin" required>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label>Tanggal Lahir *</label>
                <input type="date" name="tgl_lahir" required>
            </div>

            <div class="form-group">
                <label>Tujuan *</label>
                <select id="destinasi" required>
                    <option value="" data-price="0">Pilih destinasi</option>
                    <option value="Lombok" data-price="1000000">Lombok</option>
                    <option value="Bali" data-price="1500000">Bali</option>
                    <option value="Papua" data-price="2500000">Papua</option>
                </select>
            </div>

            <div class="form-group">
                <label>Jumlah Tiket *</label>
                <input type="number" id="jumlah" value="1" min="1">
            </div>

            <input type="hidden" name="total_harga" id="totalInput">

            <div class="total-price" id="totalText">Total: Rp 0</div>

            <div class="form-group">
                <label>Upload Bukti Pembayaran *</label>
                <input type="file" name="bukti" required>
            </div>

            <button type="submit">Order Now</button>
            <a href="<?= site_url('auth/home'); ?>" class="btn-back">Back</a>

        </div>
    </div>

</div>
</form>

</div>

<script src="<?= base_url('assets/js/order.js'); ?>"></script>
</body>
</html>
