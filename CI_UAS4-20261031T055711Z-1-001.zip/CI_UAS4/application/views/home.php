<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME - EXPLORE BEYOND</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/utama.css">
    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">
</head>
<body>
    <?php $this->load->view('navbar'); ?>
    <?php $is_logged = $this->session->userdata('login') ? true : false; ?>
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert-success" style="padding:10px;margin:10px 20px;border-radius:4px;background:#d4edda;color:#155724;">
            <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert-error" style="padding:10px;margin:10px 20px;border-radius:4px;background:#f8d7da;color:#721c24;">
            <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php endif; ?>
    <div id="navbar-placeholder"></div>
    <img src="/CI_UAS4/assets/image/bg.jpeg" alt="Explore Beyond Header" class="header-img">

    <div class="container">
        <h2>PILIH TUJUAN</h2>
        <div class="row">
            <?php if (!empty($destinasi)) : foreach ($destinasi as $d) : ?>
            <a href="<?php echo site_url('order'); ?>" class="col requires-login <?php echo !$is_logged ? 'blocked' : '' ?>" onclick="return requireLogin(event);">
                <div class="card">
                    <img src="/CI_UAS4/uploads/<?php echo isset($d->gambar) ? $d->gambar : 'default.jpg'; ?>" class="card-img" alt="<?php echo htmlspecialchars($d->nama_destinasi); ?>">
                    <div class="card-body">
                        <p class="card-title"><?php echo strtoupper($d->nama_destinasi); ?></p>
                        <p class="card-stock">Stock :<?php echo $d->stock; ?></p>
                        <p class="card-price">Rp. <?php echo number_format($d->harga,0,',','.'); ?></p>
                    </div>
                </div>
            </a>
            <?php endforeach; else: ?>
            <p>Tidak ada destinasi saat ini.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <style>
        .requires-login.blocked { 
            opacity: 0.5; 
            pointer-events: none !important; 
            cursor: not-allowed !important; 
            display: block;
        }
        .requires-login.blocked .card { 
            pointer-events: none !important; 
        }
        .requires-login.blocked:hover {
            opacity: 0.5;
        }
        .login-overlay {
            display: none;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: rgba(0,0,0,0.3);
            border-radius: 8px;
            z-index: 10;
        }
        .col.blocked .login-overlay {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            color: white;
            font-weight: bold;
            text-align: center;
        }
    </style>

    <script>
        var isLoggedIn = <?php echo $is_logged ? 'true' : 'false'; ?>;
        
        function requireLogin(e) {
            if (!isLoggedIn) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                alert('⚠️ Anda harus login terlebih dahulu untuk memilih tujuan!');
                window.location = '<?= site_url('auth/login') ?>';
                return false;
            }
            return true;
        }

        // Initialize blocked anchors
        window.addEventListener('load', function() {
            document.querySelectorAll('a.requires-login.blocked').forEach(function(a) {
                // Store original href
                a.dataset.originalHref = a.href;
                // Replace href with void
                a.href = 'javascript:void(0);';
                a.style.pointerEvents = 'none';
                a.style.cursor = 'not-allowed';
                
                // Add click handler with capture
                a.addEventListener('click', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    if (!isLoggedIn) {
                        alert('⚠️ Anda harus login terlebih dahulu untuk memilih tujuan!');
                        window.location = '<?= site_url('auth/login') ?>';
                    }
                    return false;
                }, true);
            });
        });
    </script>


    <?php $this->load->view('footer'); ?>
</body>
</html>