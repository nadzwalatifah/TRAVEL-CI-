<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Navbar</title>
    <link rel="stylesheet" href="/CI_UAS4/assets/css/nav.css">

</head>
<body>
<nav class="navbar">
    <div class="logo">
        <a href="<?= site_url('admin') ?>">EXPLORE BEYOND - ADMIN</a>
    </div>

    <ul class="nav-links">
        <li>
            <a href="<?= site_url('admin_pelanggan') ?>">Data Pelanggan</a>
        </li>
        <li>
            <a href="<?= site_url('admin/logout') ?>"
               onclick="return confirm('Yakin logout?')">
               Logout
            </a>
        </li>
    </ul>
</nav>

</body>
</html>
