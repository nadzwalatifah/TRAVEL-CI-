<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - EXPLORE BEYOND</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/login_register.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/nav.css'); ?>">
</head>
<body>
    <div class="container">
        <h3 class="title">EXPLORE BEYOND</h3>
        
        <?php if($this->session->flashdata('register_error')): ?>
            <div style="background: #ff4444; color: white; padding: 10px; margin: 10px 0; border-radius: 5px;">
                <?php echo $this->session->flashdata('register_error'); ?>
            </div>
        <?php endif; ?>
        
        <?php if($this->session->flashdata('register_success')): ?>
            <div style="background: #00C851; color: white; padding: 10px; margin: 10px 0; border-radius: 5px;">
                <?php echo $this->session->flashdata('register_success'); ?>
            </div>
        <?php endif; ?>
        
        <form id="registerForm" action="<?php echo site_url('auth/store_register'); ?>" method="POST">
            <h3>Register</h3>
            <div class="signup-link">
                <span>Already have an Account?</span>
                <p><a href="<?php echo site_url('auth/index'); ?>">Login Here</a></p>
            </div>
            
            <label for="nama">Name:</label>
            <input type="text" id="nama" name="nama" placeholder="Enter Name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter Email" required>

            <label for="password">Password (8 karakter):</label>
            <input type="password" id="password" name="password" placeholder="Enter Password (8 characters)" required maxlength="8">
            <span id="passwordError" style="font-size: 12px;"></span>

            <label for="password_confirmation">Confirm Password:</label>
            <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password (8 characters)" required maxlength="8">

            <div class="buttons">
                <button type="submit">Register</button>
                <a href="<?php echo site_url('home'); ?>" class="btn-back">Back</a>
            </div>
        </form>
    </div>
    <script src="<?php echo base_url('assets/js/register.js'); ?>"></script>
</body>
</html>