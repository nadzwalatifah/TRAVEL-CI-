-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Jan 2026 pada 11.03
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travelci`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `destinasi`
--

CREATE TABLE `destinasi` (
  `no` int(20) NOT NULL,
  `id_destinasi` int(11) NOT NULL,
  `gambar` text NOT NULL,
  `stock` int(20) NOT NULL,
  `harga` decimal(10,0) NOT NULL,
  `action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order`
--

CREATE TABLE `order` (
  `id_order` int(11) NOT NULL,
  `id_destinasi` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nama_lengkap` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tbt` date NOT NULL,
  `destinasi` varchar(55) NOT NULL,
  `tanggal_penerbangan` date DEFAULT NULL,
  `jumlah_tiket` int(3) NOT NULL,
  `metode_pembayaran` varchar(20) NOT NULL,
  `bukti` text NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order`
--

INSERT INTO `order` (`id_order`, `id_destinasi`, `date`, `nama_lengkap`, `email`, `no_hp`, `jenis_kelamin`, `tbt`, `destinasi`, `tanggal_penerbangan`, `jumlah_tiket`, `metode_pembayaran`, `bukti`, `total`) VALUES
(15, 2, '2026-01-10 17:44:06', 'keysha', 'keysha@gmail.com', '08987654321234', 'Perempuan', '2006-03-17', 'bali', '2026-01-22', 15, 'BCA', 'Colorify-AI-Image-1767835343162.png', 22500000.00),
(16, 3, '2026-01-10 17:48:40', 'keysha', 'keysha@gmail.com', '08987654321234', 'Laki-laki', '2006-03-17', 'papua', '2026-01-22', 13, 'E-Wallet', 'Colorify-AI-Image-1767835343162.png', 32500000.00),
(17, 2, '2026-01-10 17:55:55', 'keysha', 'keysha@gmail.com', '08987654321234', 'Perempuan', '2006-03-17', 'bali', '2026-01-22', 11, 'BCA', 'Colorify-AI-Image-1767835343162.png', 16500000.00),
(18, 1, '2026-01-11 04:24:14', 'wee', 'aril@gmail.com', '08572837874', 'Laki-laki', '2000-06-08', 'lombok', '2026-01-12', 2, 'E-Wallet', 'photobooth-io-gif (5).gif', 2000000.00),
(19, 1, '2026-01-11 09:11:50', 'Shafa Salsabilla Zakiah', 'shafa.salsabilla_si24@nusaputra.ac.id', '081317109547', 'Perempuan', '2026-01-13', 'lombok', '2026-01-25', 2, 'E-Wallet', '????????.jpg', 2000000.00),
(20, 4, '2026-01-11 09:22:33', 'Shafa Salsabilla Zakiah', 'shafa.salsabilla_si24@nusaputra.ac.id', '081317109547', 'Perempuan', '2006-03-02', 'sepatu', '2026-01-13', 2, 'Mandiri', 'download (14).jpeg', 12000000.00),
(21, 4, '2026-01-11 09:23:50', 'Shafa Salsabilla Zakiah', 'shafasalsabilla51199@gmail.com', '081317109547', 'Perempuan', '2006-03-02', 'sepatu', '2026-01-14', 2, 'E-Wallet', '????????.jpg', 12000000.00),
(22, 1, '2026-01-11 11:36:10', 'Najmi Putri M', 'najmiputri1105@gmail.com', '085884859355', 'Perempuan', '2005-11-28', 'Bali', '2026-01-12', 2, 'E-Wallet', 'Screenshot (2).png', 16000000.00),
(25, 7, '2026-01-11 16:22:28', 'Muhammad Razqi Akbar', 'Razqi@gmail.com', '085875395746', 'Laki-laki', '2006-01-19', 'bla', '2026-02-28', 9, 'BCA', 'Colorify-AI-Image-1767835343162.png', 1107000.00),
(26, 1, '2026-01-11 17:48:03', 'Muhammad Razqi Akbar', 'Razqi@gmail.com', '085875395746', 'Laki-laki', '2006-01-19', 'Bali', '2026-02-28', 2, 'BCA', 'Colorify-AI-Image-1767835343162.png', 16000000.00),
(27, 2, '2026-01-11 17:51:43', 'Muhammad Razqi Akbar', 'Razqi@gmail.com', '085875395746', 'Perempuan', '2006-01-19', 'Lombok', '2026-02-28', 7, 'BCA', 'Gemini_Generated_Image_solaiqsolaiqsola.png', 70000000.00),
(30, 1, '2026-01-12 01:14:16', 'ariel febrian', 'ariel@gmail.com', '081567547812', 'Laki-laki', '2006-12-28', 'Bali', '2026-12-28', 2, 'Transfer Bank', 'WhatsApp Image 2026-01-12 at 7.51.50 AM.jpeg', 16000000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tambah`
--

CREATE TABLE `tambah` (
  `id` int(11) NOT NULL,
  `nama_destinasi` varchar(55) NOT NULL,
  `gambar` text NOT NULL,
  `stock` int(15) NOT NULL,
  `harga` varchar(55) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tambah`
--

INSERT INTO `tambah` (`id`, `nama_destinasi`, `gambar`, `stock`, `harga`, `deskripsi`) VALUES
(1, 'Bali', '1768125663_ubud.jpeg', 48, '8000000', NULL),
(2, 'Lombok', '1768125729_kuta.jpeg', 50, '10000000', NULL),
(3, 'Papua', '1768125712_ampat.jpeg', 50, '12000000', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`) VALUES
(1, 'admin', '', 'admin123', 'admin'),
(2, 'ee', 'ee@gmail.com', '123456', 'user'),
(3, 'naj', 'naj@gmail.com', '23456', 'user'),
(4, 'aris', 'ari@gmail.com', 'ari123', 'user'),
(5, 'keyyjhong', 'keyyjhong@gmail.com', '123456', 'user'),
(6, 'keysha', 'keysha@gmail.com', 'zxcv', 'user'),
(7, 'zaki', 'zaki@gmail.com', 'zaki', 'user'),
(8, 'razqi', 'razqi@gmail.com', '12345678', 'user'),
(9, 'rehan', 'rehan@gmail.com', 'asdfg', 'user'),
(10, 'nanad', 'nanad@gmail.com', '12345', 'user'),
(11, 'ariel', 'ariel@gmail.com', 'ariel', 'user'),
(12, 'keyyjhong', 'keyyjhong@gmail.com', 'Keyz2006', 'user');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id_order`);

--
-- Indeks untuk tabel `tambah`
--
ALTER TABLE `tambah`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `destinasi`
--
ALTER TABLE `destinasi`
  MODIFY `no` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `order`
--
ALTER TABLE `order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `tambah`
--
ALTER TABLE `tambah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
